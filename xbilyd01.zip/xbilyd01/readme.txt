Authors: Daniel Bily(xbilyd01) and Jakub Gajdosik (xgajdo24)
VUT FIT: IJA 2018/2019
Project name: Chess game with gui and history of moves

run:(in root directory)
	ant compile
	ant run